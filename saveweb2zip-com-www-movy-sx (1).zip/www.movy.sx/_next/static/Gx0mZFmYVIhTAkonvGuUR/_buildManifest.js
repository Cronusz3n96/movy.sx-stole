self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/35ahqr7iw34z3.js"
  ],
  "/404": [
    "static/chunks/2wvhfz2zixa56.js"
  ],
  "/500": [
    "static/chunks/3ptcvuq8glf6c.js"
  ],
  "/_error": [
    "static/chunks/02potn_s8k8-e.js"
  ],
  "/anime/[...params]": [
    "static/chunks/09o8yy2tlmfrh.js"
  ],
  "/browse/[type]": [
    "static/chunks/0og6fg45xyq08.js"
  ],
  "/help": [
    "static/chunks/02qwz67u13lxg.js"
  ],
  "/history": [
    "static/chunks/1q85re6u2yt8e.js"
  ],
  "/l/[token]": [
    "static/chunks/34bdyilt-k9ne.js"
  ],
  "/legal/dmca": [
    "static/chunks/2qqhsvok76_zh.js"
  ],
  "/legal/privacy": [
    "static/chunks/2rt7xa9uzve6a.js"
  ],
  "/legal/terms": [
    "static/chunks/2ij4s-a1hexnr.js"
  ],
  "/link": [
    "static/chunks/2kfkhxjizg1d8.js"
  ],
  "/livestream/[...params]": [
    "static/chunks/0tocoljo12hym.js"
  ],
  "/movie/[...params]": [
    "static/chunks/0r7805xrq04a3.js"
  ],
  "/profiles": [
    "static/chunks/1qgfykn41e46s.js"
  ],
  "/recovery": [
    "static/chunks/3608qumdyzr41.js"
  ],
  "/robots.txt": [
    "static/chunks/1hxxajezje7se.js"
  ],
  "/sitemap.xml": [
    "static/chunks/0abaad_fm6lmi.js"
  ],
  "/tv/[...params]": [
    "static/chunks/06gzxj8cz5-c9.js"
  ],
  "/watchlist": [
    "static/chunks/1l23wl_wtk9x0.js"
  ],
  "/watchparty": [
    "static/chunks/3lesbqb5fnzeh.js"
  ],
  "/watchparty/[roomId]": [
    "static/chunks/24-zdu9mytzcp.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/404",
    "/500",
    "/_app",
    "/_error",
    "/anime/[...params]",
    "/api/avatars",
    "/api/geo",
    "/browse/[type]",
    "/help",
    "/history",
    "/l/[token]",
    "/legal/dmca",
    "/legal/privacy",
    "/legal/terms",
    "/link",
    "/livestream/[...params]",
    "/movie/[...params]",
    "/profiles",
    "/recovery",
    "/robots.txt",
    "/sitemap.xml",
    "/tv/[...params]",
    "/watchlist",
    "/watchparty",
    "/watchparty/[roomId]"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()